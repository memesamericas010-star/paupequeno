#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
#  2K Dashboard — instalador AUTÔNOMO (offline) para VPS (Ubuntu/Debian)
#  Uso:  sudo bash instalar-offline.sh
#
#  Diferente da versão online: NÃO fala com nenhum servidor de ativação.
#  A instalação é liberada por SENHA. Você pode informar de dois jeitos:
#     • interativo: o script pergunta a senha;
#     • sem tela:   sudo SENHA_INSTALACAO='...' bash instalar-offline.sh
#
#  Com a senha correta, ele instala tudo (Node, dependências, .env, serviço
#  systemd) e sobe o painel. Sem a senha, nada é instalado.
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

APP="2k-dashboard"
DIR_APP="/opt/${APP}"
USUARIO="2kbot"
NODE_MAJOR=22

vermelho() { printf '\033[31m%s\033[0m\n' "$*"; }
verde()    { printf '\033[32m%s\033[0m\n' "$*"; }
azul()     { printf '\033[36m%s\033[0m\n' "$*"; }
amarelo()  { printf '\033[33m%s\033[0m\n' "$*"; }

como_usuario() {
  if command -v runuser >/dev/null 2>&1; then runuser -u "$USUARIO" -- "$@"
  elif command -v sudo   >/dev/null 2>&1; then sudo -u "$USUARIO" -- "$@"
  else su -s /bin/sh "$USUARIO" -c "$(printf '%q ' "$@")"; fi
}

export DEBIAN_FRONTEND=noninteractive
[ "$(id -u)" -eq 0 ] || { vermelho "Rode como root:  sudo bash instalar-offline.sh"; exit 1; }

ORIGEM="$(cd "$(dirname "$0")" && pwd -P)"
azul "── 2K Dashboard · instalação autônoma (offline) ──────────────"

# 0) Ferramentas de base + Node (precisamos do node p/ conferir a senha) --------
apt-get update -y >/dev/null 2>&1 || apt-get update -y || true
apt-get install -y --no-install-recommends curl ca-certificates tar xz-utils gnupg >/dev/null 2>&1 || \
  apt-get install -y --no-install-recommends curl ca-certificates tar xz-utils gnupg || true
if ! command -v node >/dev/null 2>&1 || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt "$NODE_MAJOR" ]; then
  azul "Instalando Node.js ${NODE_MAJOR}.x ..."
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
  apt-get install -y nodejs
fi
command -v node >/dev/null 2>&1 || { vermelho "Node.js não pôde ser instalado."; exit 1; }
verde "Node $(node -v)"

# 1) SENHA DE INSTALAÇÃO (antes de instalar qualquer coisa) --------------------
azul "── Senha de instalação ────────────────────────────────────"
tentar_senha() {
  SENHA_INSTALACAO="$1" node "$ORIGEM/ferramentas/instalar-autonomo.mjs" verificar
}
OK_SENHA=0
if [ -n "${SENHA_INSTALACAO:-}" ]; then
  if tentar_senha "$SENHA_INSTALACAO"; then OK_SENHA=1; else vermelho "Senha de instalação incorreta (via ambiente)."; fi
elif [ -t 0 ]; then
  for _ in 1 2 3; do
    read -rsp "Senha de instalação: " S; echo
    if tentar_senha "$S"; then OK_SENHA=1; SENHA_INSTALACAO="$S"; break; else amarelo "Senha incorreta, tente de novo."; fi
  done
else
  vermelho "Sem terminal para digitar a senha. Rode:  sudo SENHA_INSTALACAO='...' bash instalar-offline.sh"
  exit 1
fi
[ "$OK_SENHA" = "1" ] || { vermelho "Senha não confirmada. Instalação cancelada."; exit 1; }
export SENHA_INSTALACAO
verde "Senha confirmada."

# 2) Usuário de serviço --------------------------------------------------------
if ! id "$USUARIO" >/dev/null 2>&1; then
  azul "Criando usuário de serviço '${USUARIO}' ..."
  useradd --system --create-home --shell /usr/sbin/nologin "$USUARIO"
fi

# 3) Copiar aplicação ----------------------------------------------------------
ALVO="$(mkdir -p "$DIR_APP"; cd "$DIR_APP" && pwd -P)"
if [ "$ORIGEM" = "$ALVO" ]; then
  verde "Aplicação já está em ${DIR_APP} — pulando cópia."
else
  azul "Instalando em ${DIR_APP} ..."
  tar --warning=no-file-changed \
      --exclude='./node_modules' --exclude='./.git' --exclude='./data' \
      --exclude='./auth' --exclude='./chaves-autor' --exclude='./.env' \
      -C "$ORIGEM" -cf - . | tar -C "$DIR_APP" -xf - \
    || { st=$?; [ "$st" -le 1 ] || { vermelho "Falha ao copiar (tar $st)."; exit 1; }; }
fi
mkdir -p "$DIR_APP/data" "$DIR_APP/auth"

# 4) Dependências --------------------------------------------------------------
azul "Instalando dependências (npm ci) ..."
cd "$DIR_APP"
if [ -f package-lock.json ]; then
  npm ci --omit=dev || { amarelo "npm ci falhou; tentando npm install --omit=dev ..."; npm install --omit=dev; }
else
  npm install --omit=dev
fi

# 5) .env (modo autônomo) ------------------------------------------------------
if [ ! -f "$DIR_APP/.env" ]; then
  azul "Criando .env ..."
  cp "$DIR_APP/.env.example" "$DIR_APP/.env"
  TOKEN="$(node -e 'console.log(require("crypto").randomBytes(32).toString("hex"))')"
  sed -i "s|^API_TOKEN=.*|API_TOKEN=${TOKEN}|" "$DIR_APP/.env"
  DOM="${DOMINIO:-}"
  if [ -z "$DOM" ] && [ -t 0 ]; then
    read -rp "Domínio desta instalação (ex: bot.seudominio.com) [Enter p/ pular]: " DOM || true
  fi
  sed -i "s|^DOMINIO=.*|DOMINIO=${DOM}|" "$DIR_APP/.env"
  verde "API_TOKEN gerado automaticamente e salvo no .env"
fi
# Garante o modo autônomo ligado no .env (idempotente).
if grep -qE '^MODO_AUTONOMO=' "$DIR_APP/.env"; then
  sed -i "s|^MODO_AUTONOMO=.*|MODO_AUTONOMO=1|" "$DIR_APP/.env"
else
  printf '\nMODO_AUTONOMO=1\n' >> "$DIR_APP/.env"
fi

# 6) Marcador de instalação (grava só com a senha correta) ---------------------
azul "Confirmando a instalação (marcador local) ..."
SENHA_INSTALACAO="$SENHA_INSTALACAO" node "$DIR_APP/ferramentas/instalar-autonomo.mjs" marcar --saida "$DIR_APP/data" >/dev/null \
  || { vermelho "Falha ao gravar o marcador de instalação (senha?)."; exit 1; }

chown -R "$USUARIO":"$USUARIO" "$DIR_APP"
chmod 600 "$DIR_APP/.env"
chmod 600 "$DIR_APP/data/.instalado" 2>/dev/null || true

# 7) systemd -------------------------------------------------------------------
azul "Registrando serviço systemd ..."
cat > "/etc/systemd/system/${APP}.service" <<UNIT
[Unit]
Description=2K Dashboard (autônomo)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${USUARIO}
WorkingDirectory=${DIR_APP}
EnvironmentFile=${DIR_APP}/.env
ExecStart=$(command -v node) ${DIR_APP}/server.js
Restart=on-failure
RestartSec=5
RestartPreventExitStatus=87
NoNewPrivileges=true
ProtectSystem=full

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable "${APP}" >/dev/null 2>&1 || true

# 8) Sobe e confere ------------------------------------------------------------
azul "Iniciando o serviço ..."
systemctl restart "${APP}" || true
PORTA="$(grep -E '^PORT=' "$DIR_APP/.env" | cut -d= -f2- | tr -d ' ')"; PORTA="${PORTA:-8480}"
OK=0
for _ in $(seq 1 30); do
  if curl -fsk --max-time 3 "http://127.0.0.1:${PORTA}/health" 2>/dev/null | grep -q '"ok"'; then OK=1; break; fi
  sleep 1
done
echo
if [ "$OK" = "1" ]; then
  verde "════════════════════════════════════════════════════════════"
  verde " 2K Dashboard (autônomo) instalado e RODANDO."
  verde "════════════════════════════════════════════════════════════"
else
  amarelo "Instalado, mas o serviço ainda não respondeu. Veja o log:"
  echo "   journalctl -u ${APP} -n 40 --no-pager"
fi
echo "   Pasta   : ${DIR_APP}"
echo "   Serviço : systemctl status ${APP}"
echo "   Logs    : journalctl -u ${APP} -f"
echo
verde "Instalação concluída (modo autônomo, sem servidor de ativação)."
